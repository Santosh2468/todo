import {useState} from 'react';

const TodoApp = () => {

	const [currentTodo, setCurrentTodo] = useState("");
	const [allTodos, setAllTodos] = useState([]);
	const [editIndex, setEditIndex] = useState(undefined);

	const handleSubmit = () => {
		//if editing
		if(editIndex != undefined){
			const newTodos = allTodos.map((todo, index) => {
				if(index == editIndex) return currentTodo;
				return todo;
			})
			setAllTodos(newTodos);
			setCurrentTodo("");
		} else {
			// if not editing - if user entering new value
			if(currentTodo.length>0){
				setAllTodos([...allTodos, currentTodo]);
				setCurrentTodo("")
			}
		}
	}

	const handleOnChange = (event) => {
		setCurrentTodo(event.target.value);
	}

	const handleEdit = (eIndex) => {
		setCurrentTodo(allTodos[eIndex])
		setEditIndex(eIndex)
	}
	

	const handleDelete = (index) => {
	}

    return(
      <div style={{marginTop: 100}}>
        <h1>Todo Application</h1>
		{/* Controlled */}
        <input type="text" onChange={handleOnChange} value={currentTodo} style={{marginRight: 20}} />

        <button className="btn btn-primary" onClick={handleSubmit}>Submit</button>  

				{
					allTodos.length > 0 ?
					(
						<table className="table" style={{marginTop: 20}}>
							<thead className="thead-dark">
									<tr>
										<th scope="col">SI</th>
										<th scope="col">Task</th>
										<th scope="col">Action</th>
									</tr>
							</thead>
							<tbody>
								{
									allTodos.map((todo, index) => {
										return(
											<tr key={index}>
												<td>{index+1}</td>
												<td>{todo}</td>
												<td>
													<button className='btn btn-secondary' onClick={() => { handleEdit(index) }}>Edit</button> &nbsp;
													<button className='btn btn-secondary' onClick={() => {handleDelete(index)}}>Delete</button>
												</td>
											</tr>
										)
									})
								}
							</tbody>
						</table>
					) : (<p className='text-danger'>No Todos available</p>)
				}
      </div>
    )
}

export default TodoApp;